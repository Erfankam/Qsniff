#include <stdio.h>
#include <pcap.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>

#include "flow_manager/flow_manager.h"

#define ETHER_TYPE_IP (0x0800)
#define ETHER_TYPE_IP6 (0x86DD)
#define ETHER_TYPE_VLAN (0x8100)

struct ethernet_header {
	uint8_t dest_mac[6];
	uint8_t source_mac[6];
	uint16_t ethertype;
};

struct vlan_header {
	uint16_t vlan_id; /* NOTE: includes priority and format fields */
	uint16_t ethertype;
};

double ts = 0.0;
char *local_mac = NULL;
uint8_t mac_bytes[6];

u_char *find_transport_ip6(u_char *ptr, uint32_t *rlen, uint8_t next, uint8_t *proto, uint32_t *plen) {

	while (*rlen > 0) {
		struct ip6_ext *ext;
		switch (next) {
			case 44: /* Fragments */
				return NULL;
			case 43: /* Routing */
			case 51: /* Authentication */
			case 60: /* Dest Options */
				ext =  (struct ip6_ext *)ptr;
				next = ext->ip6e_nxt;
				if (*rlen < (ext->ip6e_len * 8) + 8) {
					*rlen = 0;
					return ptr;
				}
				ptr += (ext->ip6e_len * 8) + 8;
				*rlen -= (ext->ip6e_len * 8) + 8;
				*plen -= (ext->ip6e_len * 8) + 8;
				break;
			default:
				*proto = next;
				return ptr;
		}

	}

	return ptr;
}

void per_packet(u_char *args, const struct pcap_pkthdr *header, const u_char *packet) {

	Flow *f;
	fm_param_t param;
	struct ethernet_header *eth;
	struct vlan_header *vlan;
	uint32_t rlen = 0;
	uint16_t ethertype = 0;
	u_char *ptr = (u_char *)packet;
	uint8_t trans_proto = 0;
	struct tcphdr *tcp;

	ts = header->ts.tv_sec + ((header->ts.tv_usec * 1.0) / 1000000);
	rlen = header->caplen; 

	while ((f = fm_expire_next_flow(ts, false)) != NULL) {
		fm_report_summary(f);
	}

	f = NULL;

	if (rlen < sizeof(struct ethernet_header))
		return;
	eth = (struct ethernet_header *)packet;

	memset(&param, 0, sizeof(param));


	if (memcmp(eth->source_mac, mac_bytes, 6) == 0)
		param.dir = 0;
	else if (memcmp(eth->dest_mac, mac_bytes, 6) == 0)
		param.dir = 1;
	else
		return;
	
	ethertype = ntohs(eth->ethertype);
	ptr += sizeof(struct ethernet_header);
	rlen -= sizeof(struct ethernet_header);

	while (ethertype != ETHER_TYPE_IP && ethertype != ETHER_TYPE_IP6) {

		switch (ethertype) {
			case ETHER_TYPE_VLAN:
				if (rlen < sizeof(struct vlan_header))
					return;
				vlan = (struct vlan_header *)ptr;
				ethertype = ntohs(vlan->ethertype);
				ptr += sizeof(struct vlan_header);
				rlen -= sizeof(struct vlan_header);
				break;
			default:
				return;
		}

	}

	if (ethertype == ETHER_TYPE_IP) {
		struct iphdr *ip = (struct iphdr *)ptr;

		if (rlen < sizeof(struct iphdr))
			return;
		if ((ntohs(ip->frag_off) & 0x1fff) != 0)
			return;
		param.ip_version = 4;
		param.src_ip = ip->saddr;
		param.dest_ip = ip->daddr;
		param.payload_bytes = ntohs(ip->tot_len) - (ip->ihl * 4);

		ptr += (ip->ihl * 4);
		rlen -= (ip->ihl * 4);
		trans_proto = ip->protocol;
	} 
	
	if (ethertype == ETHER_TYPE_IP6 || trans_proto == 41) {
		struct ip6_hdr *ip6 = (struct ip6_hdr *)ptr;

		if (rlen < sizeof(struct ip6_hdr))
			return;
		if (param.ip_version != 4) {
			param.ip_version = 6;
			memcpy(param.src_ip6, &ip6->ip6_src, sizeof(param.src_ip6));
			memcpy(param.dest_ip6, &ip6->ip6_dst, sizeof(param.dest_ip6));
		}
		param.payload_bytes = ntohs(ip6->ip6_plen);

		ptr += sizeof(struct ip6_hdr);
		rlen -= sizeof(struct ip6_hdr);

		ptr = find_transport_ip6(ptr, &rlen, ip6->ip6_nxt, &trans_proto, &param.payload_bytes);

		if (ptr == NULL)
			return;
	}

	if (trans_proto != 6)
		return;
	
	tcp = (struct tcphdr *)ptr;
	
	if (rlen < sizeof(struct tcphdr))
		return;
	param.src_port = ntohs(tcp->source);
	param.dest_port = ntohs(tcp->dest);
	param.proto = 6;
	param.syn = tcp->syn;
	param.ack = tcp->ack;
	param.fin = tcp->fin;
	param.rst = tcp->rst;

	if (param.payload_bytes < (tcp->doff * 4))
		param.payload_bytes = 0;
	else
		param.payload_bytes -= (tcp->doff * 4);

	
	f = fm_match_flow(param);

	if (!f) return;
	fm_update_stats(f, param, ts);
	fm_update_expiry(f, param, ts);

}

int main(int argc, char *argv[]) {

	char *filterstring = NULL;
	int opt, i;
	struct bpf_program fp;
	Flow *f;

 	while ((opt = getopt(argc, argv, "l:f:")) != EOF) {
                switch(opt) {
                        case 'l':
                                local_mac = optarg;
                                break;
                        case 'f':
                                filterstring = optarg;
                                break;
                }
        }
	
	if (local_mac != NULL) {
		if (convert_mac_string(local_mac, mac_bytes) < 0) {
			fprintf(stderr, "Invalid MAC: %s\n", local_mac);
			return 1;
		}
	} else {
		fprintf(stderr, "Warning: No Local MAC specified (-l)\n");
	}

	for(i=optind; i < argc; i++) {
		fprintf(stderr, "%s\n", argv[i]);
		pcap_t *handle;
		char errbuf[PCAP_ERRBUF_SIZE];
		handle = pcap_open_offline(argv[i], errbuf);
		int ret;

		if (handle == NULL) {
			fprintf(stderr, "Could not open file: %s\n", errbuf);
			return 1;
		}

		if (pcap_datalink(handle) != DLT_EN10MB) {
			pcap_close(handle);
			continue;
		}

		if (filterstring) {
			if (pcap_compile(handle, &fp, filterstring, 0, 0) == -1) {
				fprintf(stderr, "Unable to parse filter: %s\n", pcap_geterr(handle));
				return 1;
			}
			if (pcap_setfilter(handle, &fp) == -1) {
				fprintf(stderr, "Unable to set filter: %s\n", pcap_geterr(handle));
				return 1;
			}
				
		}

		ret = pcap_loop(handle, -1, per_packet, NULL);
		
		if (ret == -1) {
			fprintf(stderr, "Error reading packets: %s\n", pcap_geterr(handle));
			return 1;
		}
		
		if (filterstring)
			pcap_freecode(&fp);
		pcap_close(handle);
		
	}
	while (f = fm_expire_next_flow(ts, true))
		fm_report_summary(f);
	
}
