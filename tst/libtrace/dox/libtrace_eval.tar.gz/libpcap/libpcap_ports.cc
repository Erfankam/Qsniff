#include <stdio.h>
#include <pcap.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <arpa/inet.h>

#define ETHER_TYPE_IP (0x0800)
#define ETHER_TYPE_IP6 (0x86DD)
#define ETHER_TYPE_VLAN (0x8100)

struct ethernet_header {
	uint8_t dest_mac[6];
	uint8_t source_mac[6];
	uint16_t ethertype;
};

struct vlan_header {
	uint16_t vlan_id; /* NOTE: includes priority and format fields */
	uint16_t ethertype;
};

char *local_mac = NULL;
uint8_t mac_bytes[6];

struct port_counter {
        uint64_t bytes_in;
        uint64_t bytes_out;
        uint64_t pkts_in;
        uint64_t pkts_out;
};

struct port_counter tcp_src_stats[65536];
struct port_counter tcp_dest_stats[65536];
struct port_counter udp_src_stats[65536];
struct port_counter udp_dest_stats[65536];

int convert_mac_string(char *string, uint8_t *bytes) {

        uint32_t digits[6];

        if (sscanf(string, "%x:%x:%x:%x:%x:%x", &(digits[0]),
                        &(digits[1]), &(digits[2]), &(digits[3]),
                        &(digits[4]), &(digits[5])) != 6)
                return -1;

        for (int i = 0; i < 6; i++) {

                if (digits[i] > 255)
                        return -1;
                bytes[i] = (uint8_t)digits[i];
        }

        return 0;

}


u_char *find_transport_ip6(u_char *ptr, uint32_t *rlen, uint8_t next, uint8_t *proto, uint32_t *plen) {

	while (*rlen > 0) {
		struct ip6_ext *ext;
		switch (next) {
			case 44: /* Fragments */
				return NULL;
			case 43: /* Routing */
			case 51: /* Authentication */
			case 60: /* Dest Options */
				ext =  (struct ip6_ext *)ptr;
				next = ext->ip6e_nxt;
				if (*rlen < (ext->ip6e_len * 8) + 8) {
					*rlen = 0;
					return ptr;
				}
				ptr += (ext->ip6e_len * 8) + 8;
				*rlen -= (ext->ip6e_len * 8) + 8;
				*plen -= (ext->ip6e_len * 8) + 8;
				break;
			default:
				*proto = next;
				return ptr;
		}

	}

	return ptr;
}

void per_packet(u_char *args, const struct pcap_pkthdr *header, const u_char *packet) {

	struct ethernet_header *eth;
	struct vlan_header *vlan;
	uint32_t rlen = 0;
	uint16_t ethertype = 0;
	u_char *ptr = (u_char *)packet;
	uint8_t trans_proto = 0;
	struct tcphdr *tcp;
	uint32_t payload_bytes = 0;
	uint16_t src_port, dst_port;
	uint8_t dir = 2;

	rlen = header->caplen; 

	if (rlen < sizeof(struct ethernet_header))
		return;
	eth = (struct ethernet_header *)packet;

	if (memcmp(eth->source_mac, mac_bytes, 6) == 0)
		dir = 0;
	else if (memcmp(eth->dest_mac, mac_bytes, 6) == 0)
		dir = 1;
	else
		return;
	
	ethertype = ntohs(eth->ethertype);
	ptr += sizeof(struct ethernet_header);
	rlen -= sizeof(struct ethernet_header);

	while (ethertype != ETHER_TYPE_IP && ethertype != ETHER_TYPE_IP6) {

		switch (ethertype) {
			case ETHER_TYPE_VLAN:
				if (rlen < sizeof(struct vlan_header))
					return;
				vlan = (struct vlan_header *)ptr;
				ethertype = ntohs(vlan->ethertype);
				ptr += sizeof(struct vlan_header);
				rlen -= sizeof(struct vlan_header);
				break;
			default:
				return;
		}

	}

	if (ethertype == ETHER_TYPE_IP) {
		struct iphdr *ip = (struct iphdr *)ptr;

		if (rlen < sizeof(struct iphdr))
			return;
		if (ntohs(ip->tot_len) < rlen)
			rlen = ntohs(ip->tot_len);
		if ((ntohs(ip->frag_off) & 0x1fff) != 0)
			return;
		payload_bytes = ntohs(ip->tot_len) - (ip->ihl * 4);

		ptr += (ip->ihl * 4);
		rlen -= (ip->ihl * 4);
		trans_proto = ip->protocol;
	} 
	
	if (ethertype == ETHER_TYPE_IP6 || trans_proto == 41) {
		struct ip6_hdr *ip6 = (struct ip6_hdr *)ptr;

		if (rlen < sizeof(struct ip6_hdr))
			return;
		payload_bytes = ntohs(ip6->ip6_plen);

		ptr += sizeof(struct ip6_hdr);
		rlen -= sizeof(struct ip6_hdr);

		ptr = find_transport_ip6(ptr, &rlen, ip6->ip6_nxt, &trans_proto, &payload_bytes);
		if (ptr == NULL)
			return;
	}

	if (trans_proto == 6) {

		tcp = (struct tcphdr *)ptr;
	
		if (rlen < sizeof(struct tcphdr))
			return;
		src_port = ntohs(tcp->source);
		dst_port = ntohs(tcp->dest);

		if (payload_bytes < (tcp->doff * 4) || rlen < sizeof(struct tcphdr))
			payload_bytes = 0;
		else
			payload_bytes -= (tcp->doff * 4);

		if (dir == 0) {
			tcp_src_stats[src_port].bytes_out += payload_bytes;
			tcp_src_stats[src_port].pkts_out ++;
			tcp_dest_stats[dst_port].bytes_out += payload_bytes;
			tcp_dest_stats[dst_port].pkts_out ++;
		} else {
			tcp_src_stats[src_port].bytes_in += payload_bytes;
			tcp_src_stats[src_port].pkts_in ++;
			tcp_dest_stats[dst_port].bytes_in += payload_bytes;
			tcp_dest_stats[dst_port].pkts_in ++;
		}
	} 

	if (trans_proto == 17) {
		struct udphdr *udp = (struct udphdr *)ptr;

		if (rlen < sizeof(struct udphdr))
			return;
		src_port = ntohs(udp->source);
		dst_port = ntohs(udp->dest);

		if (payload_bytes < sizeof(struct udphdr) || rlen < sizeof(struct udphdr))
			payload_bytes = 0;
		else
			payload_bytes -= sizeof(struct udphdr);

		if (dir == 0) {
			udp_src_stats[src_port].bytes_out += payload_bytes;
			udp_src_stats[src_port].pkts_out ++;
			udp_dest_stats[dst_port].bytes_out += payload_bytes;
			udp_dest_stats[dst_port].pkts_out ++;
		} else {
			udp_src_stats[src_port].bytes_in += payload_bytes;
			udp_src_stats[src_port].pkts_in ++;
			udp_dest_stats[dst_port].bytes_in += payload_bytes;
			udp_dest_stats[dst_port].pkts_in ++;
		}
	}
	


}

int main(int argc, char *argv[]) {

	char *filterstring = NULL;
	int opt, i;
	struct bpf_program fp;

 	while ((opt = getopt(argc, argv, "l:f:")) != EOF) {
                switch(opt) {
                        case 'l':
                                local_mac = optarg;
                                break;
                        case 'f':
                                filterstring = optarg;
                                break;
                }
        }

        memset(tcp_src_stats, 0, sizeof(struct port_counter) * 65536);
        memset(tcp_dest_stats, 0, sizeof(struct port_counter) * 65536);
        memset(udp_src_stats, 0, sizeof(struct port_counter) * 65536);
        memset(udp_dest_stats, 0, sizeof(struct port_counter) * 65536);


	
	if (local_mac != NULL) {
		if (convert_mac_string(local_mac, mac_bytes) < 0) {
			fprintf(stderr, "Invalid MAC: %s\n", local_mac);
			return 1;
		}
	} else {
		fprintf(stderr, "Warning: No Local MAC specified (-l)\n");
	}

	for(i=optind; i < argc; i++) {
		fprintf(stderr, "%s\n", argv[i]);
		pcap_t *handle;
		char errbuf[PCAP_ERRBUF_SIZE];
		handle = pcap_open_offline(argv[i], errbuf);
		int ret;

		if (handle == NULL) {
			fprintf(stderr, "Could not open file: %s\n", errbuf);
			return 1;
		}

		if (pcap_datalink(handle) != DLT_EN10MB) {
			pcap_close(handle);
			continue;
		}

		if (filterstring) {
			if (pcap_compile(handle, &fp, filterstring, 0, 0) == -1) {
				fprintf(stderr, "Unable to parse filter: %s\n", pcap_geterr(handle));
				return 1;
			}
			if (pcap_setfilter(handle, &fp) == -1) {
				fprintf(stderr, "Unable to set filter: %s\n", pcap_geterr(handle));
				return 1;
			}
				
		}

		ret = pcap_loop(handle, -1, per_packet, NULL);
		
		if (ret == -1) {
			fprintf(stderr, "Error reading packets: %s\n", pcap_geterr(handle));
			return 1;
		}
		
		if (filterstring)
			pcap_freecode(&fp);
		pcap_close(handle);
		
	}

        for (int i = 0; i < 65536; i++) {

                printf("%u  %lu %lu %lu %lu  %lu %lu %lu %lu  %lu %lu %lu %lu  %lu %lu %lu %lu\n",
                                i,
                                tcp_src_stats[i].pkts_out,
                                tcp_src_stats[i].bytes_out,
                                tcp_src_stats[i].pkts_in,
                                tcp_src_stats[i].bytes_in,
                                tcp_dest_stats[i].pkts_out,
                                tcp_dest_stats[i].bytes_out,
                                tcp_dest_stats[i].pkts_in,
                                tcp_dest_stats[i].bytes_in,
                                udp_src_stats[i].pkts_out,
                                udp_src_stats[i].bytes_out,
                                udp_src_stats[i].pkts_in,
                                udp_src_stats[i].bytes_in,
                                udp_dest_stats[i].pkts_out,
                                udp_dest_stats[i].bytes_out,
                                udp_dest_stats[i].pkts_in,
                                udp_dest_stats[i].bytes_in);

        }

	return 0;	
}
