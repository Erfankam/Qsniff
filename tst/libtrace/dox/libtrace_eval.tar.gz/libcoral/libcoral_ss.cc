#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ether.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <sys/param.h>
#include <libcoral.h>
#include <coral-config.h>
#include <crl_byteorder.h>

#include "flow_manager/flow_manager.h"

char *local_mac = NULL;
uint8_t mac_bytes[6];
double ts = 0.0;

void per_packet(coral_iface_t *iface, const coral_timestamp_t *timestamp,
		void *data, coral_pkt_buffer_t *packet, 
		coral_pkt_buffer_t *header, coral_pkt_buffer_t *trailer) {

	struct ether_header *ether;
	uint32_t ip_rem = 0;
	coral_pkt_buffer_t layer;	
	coral_pkt_buffer_t transport;	
	Flow *f;
	fm_param_t param;
	
	ts = coral_read_clock_double(iface, timestamp);
	
	while ((f = fm_expire_next_flow(ts, false)) != NULL) {
                fm_report_summary(f);
        }

        f = NULL;
	memset(&param, 0, sizeof(param));		
	

	if (packet->protocol != CORAL_DLT_ETHER)
		return;
	if (packet->caplen < sizeof(struct ether_header))
		return;
	ether = (struct ether_header *)packet->buf;	

        if (memcmp(ether->ether_shost, mac_bytes, 6) == 0)
                param.dir = 0;
        else if (memcmp(ether->ether_dhost, mac_bytes, 6) == 0)
                param.dir = 1;
        else
                return;

	if (coral_get_payload_by_layer(packet, &layer, 3) != 0)
		return;
	
	if (layer.protocol == CORAL_NETPROTO_IPv4) {
		struct ip *ip = (struct ip *)layer.buf;
		if (layer.caplen < sizeof(struct ip))
			return;
		if ((ntohs(ip->ip_off) & 0x1fff) != 0)
			return;
		param.payload_bytes = ntohs(ip->ip_len);
		param.ip_version = 4;
                param.src_ip = ip->ip_src.s_addr;
                param.dest_ip = ip->ip_dst.s_addr;

		ip_rem = layer.caplen;
	}

	else if (layer.protocol == CORAL_NETPROTO_IPv6) {
		struct ip6_hdr *ip6 = (struct ip6_hdr *)layer.buf;
		if (layer.caplen < sizeof(struct ip6_hdr))
			return;
		param.payload_bytes = ntohs(ip6->ip6_plen);
		param.ip_version = 6;
		memcpy(param.src_ip6, &ip6->ip6_src, sizeof(param.src_ip6));
		memcpy(param.dest_ip6, &ip6->ip6_dst, sizeof(param.dest_ip6));
		ip_rem = layer.caplen;
	} else {
		return;
	}

	if (coral_get_payload_by_layer(&layer, &transport, 4) != 0)
		return;
	
	if (transport.protocol == CORAL_IPPROTO_TCP) {
		struct tcphdr *tcp = (struct tcphdr *)transport.buf;
		if (transport.caplen < sizeof(struct tcphdr))
			return;
		param.src_port = ntohs(tcp->th_sport);
		param.dest_port = ntohs(tcp->th_dport);
		param.proto = 6;
		if (tcp->th_flags & TH_SYN)
			param.syn = true;
		if (tcp->th_flags & TH_ACK)
			param.ack = true;
		if (tcp->th_flags & TH_FIN)
			param.fin = true;
		if (tcp->th_flags & TH_RST)
			param.rst = true;

		assert(transport.caplen < ip_rem);
		param.payload_bytes -= (ip_rem - transport.caplen);
		if (param.payload_bytes < (tcp->th_off * 4))
			param.payload_bytes = 0;
		else
			param.payload_bytes -= (tcp->th_off * 4);
	} else 
		return;

	f = fm_match_flow(param);

        if (!f) return;
        fm_update_stats(f, param, ts);
        fm_update_expiry(f, param, ts);

}

int main(int argc, char *argv[]) {

	char *filterstring = NULL;
	int opt, i;
	Flow *f;

	while ((opt = getopt(argc, argv, "l:f:")) != EOF) {
                switch(opt) {
                        case 'l':
                                local_mac = optarg;
                                break;
                        case 'f':
                                filterstring = optarg;
                                break;
                }
        }

        if (local_mac != NULL) {
                if (convert_mac_string(local_mac, mac_bytes) < 0) {
                        fprintf(stderr, "Invalid MAC: %s\n", local_mac);
                        return 1;
                }
        } else {
                fprintf(stderr, "Warning: No Local MAC specified (-l)\n");
        }

	coral_set_api(CORAL_API_PKT);
	coral_set_duration(0);
	coral_set_options(0, CORAL_OPT_SORT_TIME);


	if (coral_config_command("iomode=nif=4") < 0) {
		fprintf(stderr, "Unable to set number of interfaces\n");
		return 1;
	}
	if (filterstring) {
		if (coral_add_pcap_filter(filterstring) < 0) {
			fprintf(stderr, "Unable to configure filter\n");
			return 1;
		}
	}

	coral_read_pkt_init(NULL, NULL, NULL);

        for(i=optind; i < argc; i++) {
		coral_source_t *src;

		int ret;
		if ((src = coral_new_source(argv[i])) == NULL) {
			fprintf(stderr, "Unable to create source: %s\n", argv[i]);
			return 1;
		}
		if (coral_open(src) == -1) {
			fprintf(stderr, "Unable to open source: %s\n", argv[i]);
			return 1;
		}
		if (coral_start(src) == -1) {
			fprintf(stderr, "Unable to start source: %s\n", argv[i]);
			return 1;
		}
	
		ret = coral_read_pkts(src, NULL, per_packet, NULL, NULL, NULL, NULL);
		if (ret == -1) {
			fprintf(stderr, "Error reading packets: %d\n", errno);
			return 1;
		}
		
		if (coral_stop(src) == -1) {
			fprintf(stderr, "Unable to stop source: %s\n", argv[i]);
			return 1;
		}

		coral_close(src);
	}


	while (f = fm_expire_next_flow(ts, true))
		fm_report_summary(f);
}
