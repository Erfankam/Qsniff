#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ether.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <sys/param.h>
#include <libcoral.h>
#include <coral-config.h>
#include <crl_byteorder.h>

char *local_mac = NULL;
uint8_t mac_bytes[6];

struct port_counter {
	uint64_t bytes_in;
	uint64_t bytes_out;
	uint64_t pkts_in;
	uint64_t pkts_out;
};

struct port_counter tcp_src_stats[65536];
struct port_counter tcp_dest_stats[65536];
struct port_counter udp_src_stats[65536];
struct port_counter udp_dest_stats[65536];

void per_packet(coral_iface_t *iface, const coral_timestamp_t *timestamp,
		void *data, coral_pkt_buffer_t *packet,
		coral_pkt_buffer_t *header, coral_pkt_buffer_t *trailer) {

	struct ether_header *ether;
	uint8_t dir;
	uint32_t plen = 0;
	uint32_t ip_rem = 0;
	coral_pkt_buffer_t layer;	
	coral_pkt_buffer_t transport;	
	uint16_t src_port, dst_port;


	if (packet->protocol != CORAL_DLT_ETHER)
		return;
	if (packet->caplen < sizeof(struct ether_header))
		return;
	ether = (struct ether_header *)packet->buf;	

        if (memcmp(ether->ether_shost, mac_bytes, 6) == 0)
                dir = 0;
        else if (memcmp(ether->ether_dhost, mac_bytes, 6) == 0)
                dir = 1;
        else
                return;

	if (coral_get_payload_by_layer(packet, &layer, 3) != 0)
		return;
	
	if (layer.protocol == CORAL_NETPROTO_IPv4) {
		struct ip *ip = (struct ip *)layer.buf;
		if (layer.caplen < sizeof(struct ip))
			return;
		plen = ntohs(ip->ip_len);
	}

	else if (layer.protocol == CORAL_NETPROTO_IPv6) {
		struct ip6_hdr *ip6 = (struct ip6_hdr *)layer.buf;
		if (layer.caplen < sizeof(struct ip6_hdr))
			return;
		plen = ntohs(ip6->ip6_plen);
	} else {
		return;
	}
	
	if (plen < layer.caplen)
		ip_rem = plen;
	else
		ip_rem = layer.caplen;

	if (coral_get_payload_by_layer(&layer, &transport, 4) != 0)
		return;
	
	if (transport.protocol == CORAL_IPPROTO_TCP) {
		struct tcphdr *tcp = (struct tcphdr *)transport.buf;
		if (transport.caplen < sizeof(struct tcphdr))
			return;
		src_port = ntohs(tcp->th_sport);
		dst_port = ntohs(tcp->th_dport);

		assert(transport.caplen <= ip_rem);
		plen -= (ip_rem - transport.caplen);
		if (transport.caplen < sizeof(struct tcphdr) || 
				plen < (tcp->th_off * 4))
			plen = 0;
		else
			plen -= (tcp->th_off * 4);

		if (dir == 0) {
                        tcp_src_stats[src_port].bytes_out += plen;
                        tcp_src_stats[src_port].pkts_out ++;
                        tcp_dest_stats[dst_port].bytes_out += plen;
                        tcp_dest_stats[dst_port].pkts_out ++;
                } else {
                        tcp_src_stats[src_port].bytes_in += plen;
                        tcp_src_stats[src_port].pkts_in ++;
                        tcp_dest_stats[dst_port].bytes_in += plen;
                        tcp_dest_stats[dst_port].pkts_in ++;
                }
	
	} else if (transport.protocol == CORAL_IPPROTO_UDP) {

		struct udphdr *udp = (struct udphdr *)transport.buf;
		if (transport.caplen < sizeof(struct udphdr))
			return;
		src_port = ntohs(udp->uh_sport);
		dst_port = ntohs(udp->uh_dport);

		assert(transport.caplen < ip_rem);
		
		plen -= (ip_rem - transport.caplen);
		if (plen < sizeof(struct udphdr))
			plen = 0;
		else
			plen -= sizeof(struct udphdr);

		if (dir == 0) {
                        udp_src_stats[src_port].bytes_out += plen;
                        udp_src_stats[src_port].pkts_out ++;
                        udp_dest_stats[dst_port].bytes_out += plen;
                        udp_dest_stats[dst_port].pkts_out ++;
                } else {
                        udp_src_stats[src_port].bytes_in += plen;
                        udp_src_stats[src_port].pkts_in ++;
                        udp_dest_stats[dst_port].bytes_in += plen;
                        udp_dest_stats[dst_port].pkts_in ++;
                }

	}


}

int convert_mac_string(char *string, uint8_t *bytes) {

        uint32_t digits[6];

        if (sscanf(string, "%x:%x:%x:%x:%x:%x", &(digits[0]),
                        &(digits[1]), &(digits[2]), &(digits[3]),
                        &(digits[4]), &(digits[5])) != 6)
                return -1;

        for (int i = 0; i < 6; i++) {

                if (digits[i] > 255)
                        return -1;
                bytes[i] = (uint8_t)digits[i];
        }

        return 0;

}

int main(int argc, char *argv[]) {

	char *filterstring = NULL;
	int opt, i;

	while ((opt = getopt(argc, argv, "l:f:")) != EOF) {
                switch(opt) {
                        case 'l':
                                local_mac = optarg;
                                break;
                        case 'f':
                                filterstring = optarg;
                                break;
                }
        }

        memset(tcp_src_stats, 0, sizeof(struct port_counter) * 65536);
        memset(tcp_dest_stats, 0, sizeof(struct port_counter) * 65536);
        memset(udp_src_stats, 0, sizeof(struct port_counter) * 65536);
        memset(udp_dest_stats, 0, sizeof(struct port_counter) * 65536);



        if (local_mac != NULL) {
                if (convert_mac_string(local_mac, mac_bytes) < 0) {
                        fprintf(stderr, "Invalid MAC: %s\n", local_mac);
                        return 1;
                }
        } else {
                fprintf(stderr, "Warning: No Local MAC specified (-l)\n");
        }

	coral_set_api(CORAL_API_PKT);
	coral_set_duration(0);
	coral_set_options(0, CORAL_OPT_SORT_TIME);


	if (coral_config_command("iomode=nif=4") < 0) {
		fprintf(stderr, "Unable to set number of interfaces\n");
		return 1;
	}
	if (filterstring) {
		if (coral_add_pcap_filter(filterstring) < 0) {
			fprintf(stderr, "Unable to configure filter\n");
			return 1;
		}
	}

	coral_read_pkt_init(NULL, NULL, NULL);

        for(i=optind; i < argc; i++) {
		coral_source_t *src;

		int ret;
		if ((src = coral_new_source(argv[i])) == NULL) {
			fprintf(stderr, "Unable to create source: %s\n", argv[i]);
			return 1;
		}
		if (coral_open(src) == -1) {
			fprintf(stderr, "Unable to open source: %s\n", argv[i]);
			return 1;
		}
		if (coral_start(src) == -1) {
			fprintf(stderr, "Unable to start source: %s\n", argv[i]);
			return 1;
		}
		
		ret = coral_read_pkts(src, NULL, per_packet, NULL, NULL, NULL, NULL);
		if (ret == -1) {
			fprintf(stderr, "Error reading packets: %d\n", errno);
			return 1;
		}
		
		if (coral_stop(src) == -1) {
			fprintf(stderr, "Unable to stop source: %s\n", argv[i]);
			return 1;
		}

		coral_close(src);
	}

	for (int i = 0; i < 65536; i++) {

                printf("%u  %lu %lu %lu %lu  %lu %lu %lu %lu  %lu %lu %lu %lu  %lu %lu %lu %lu\n",
                                i,
                                tcp_src_stats[i].pkts_out,
                                tcp_src_stats[i].bytes_out,
                                tcp_src_stats[i].pkts_in,
                                tcp_src_stats[i].bytes_in,
                                tcp_dest_stats[i].pkts_out,
                                tcp_dest_stats[i].bytes_out,
                                tcp_dest_stats[i].pkts_in,
                                tcp_dest_stats[i].bytes_in,
                                udp_src_stats[i].pkts_out,
                                udp_src_stats[i].bytes_out,
                                udp_src_stats[i].pkts_in,
                                udp_src_stats[i].bytes_in,
                                udp_dest_stats[i].pkts_out,
                                udp_dest_stats[i].bytes_out,
                                udp_dest_stats[i].pkts_in,
                                udp_dest_stats[i].bytes_in);

        }

        return 0;
}
