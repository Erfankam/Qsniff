#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <getopt.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ether.h>

#include <libnd.h>
#include <plugins/libnd_bpf.h>

uint8_t mac_bytes[6];
char *local_mac = NULL;
LND_Protocol *eth = NULL;
LND_Protocol *ip = NULL;
LND_Protocol *ip6 = NULL;
LND_Protocol *tcp = NULL;
LND_Protocol *udp = NULL;
LND_Protocol *icmp = NULL;
LND_Plugin *bpf = NULL;

struct port_counter {
	uint64_t bytes_in;
	uint64_t bytes_out;
	uint64_t pkts_in;
	uint64_t pkts_out;
};

struct port_counter tcp_src_stats[65536];
struct port_counter tcp_dest_stats[65536];
struct port_counter udp_src_stats[65536];
struct port_counter udp_dest_stats[65536];

int convert_mac_string(char *string, uint8_t *bytes) {

        uint32_t digits[6];

        if (sscanf(string, "%x:%x:%x:%x:%x:%x", &(digits[0]),
                        &(digits[1]), &(digits[2]), &(digits[3]),
                        &(digits[4]), &(digits[5])) != 6)
                return -1;

        for (int i = 0; i < 6; i++) {

                if (digits[i] > 255)
                        return -1;
                bytes[i] = (uint8_t)digits[i];
        }

        return 0;

}


void per_packet(LND_Packet *packet, double ts) {
	struct ether_header *ethhdr = NULL;
	guchar *trans_end = NULL;
	guchar *ip_end = NULL;
	struct tcphdr *tcphdr = NULL;
	struct udphdr *udphdr = NULL;
	uint16_t src_port, dst_port;
	uint8_t dir;
	uint32_t plen = 0;

	if (!libnd_packet_has_complete_header(packet, eth, 0))
		return;
	ethhdr = (struct ether_header *)libnd_packet_get_data(packet, eth, 0);
	assert(ethhdr);

	if (memcmp(ethhdr->ether_shost, mac_bytes, 6) == 0)
		dir = 0;
	else if (memcmp(ethhdr->ether_dhost, mac_bytes, 6) == 0)
		dir = 1;
	else {
		return;
	}

	if (libnd_packet_has_complete_header(packet, ip, 0)) {
		struct iphdr *iphdr = (struct iphdr *)libnd_packet_get_data(packet, ip, 0);
		if ((ntohs(iphdr->frag_off) & 0x1fff) != 0)
			return;
		plen = ntohs(iphdr->tot_len) - (iphdr->ihl * 4);
		ip_end = ((guchar *)iphdr) + (iphdr->ihl * 4);
		
	} 

	if (libnd_packet_has_complete_header(packet, ip6, 0)) {
		struct ip6_hdr *ip6hdr = (struct ip6_hdr *) libnd_packet_get_data(packet, ip6, 0);
		ip_end = ((guchar *)ip6hdr) + sizeof(struct ip6_hdr);
		plen = ntohs(ip6hdr->ip6_plen);
	}
	if (!ip_end)
		return;
	
	/* Ignore ICMP, because libnetdude will give us the TCP header inside
	 * the ICMP payload if we're not careful */
	if (libnd_packet_get_data(packet, icmp, 0))
		return;

	tcphdr = (struct tcphdr *)libnd_packet_get_data(packet, tcp, 0);
	
	if (tcphdr && plen >= sizeof(struct tcphdr)) {
		
		src_port = ntohs(tcphdr->source);
		dst_port = ntohs(tcphdr->dest);
		trans_end = ((guchar *)tcphdr) + (tcphdr->doff * 4);

		if (trans_end > libnd_packet_get_data_end(packet, tcp, 0))
			trans_end = libnd_packet_get_data_end(packet, tcp, 0);
		assert(trans_end - ip_end <= plen);
		plen -= (trans_end - ip_end);
		
		if (dir == 0) {
			tcp_src_stats[src_port].bytes_out += plen;
                        tcp_src_stats[src_port].pkts_out ++;
                        tcp_dest_stats[dst_port].bytes_out += plen;
                        tcp_dest_stats[dst_port].pkts_out ++;
                } else {
                        tcp_src_stats[src_port].bytes_in += plen;
                        tcp_src_stats[src_port].pkts_in ++;
                        tcp_dest_stats[dst_port].bytes_in += plen;
                        tcp_dest_stats[dst_port].pkts_in ++;
                }
			
	}
	
	udphdr = (struct udphdr *)libnd_packet_get_data(packet, udp, 0);
	
	if (udphdr && plen >= sizeof(struct udphdr)) {
		
		src_port = ntohs(udphdr->source);
		dst_port = ntohs(udphdr->dest);
		trans_end = ((guchar *)udphdr) + sizeof(struct udphdr);

		if (trans_end > libnd_packet_get_data_end(packet, udp, 0))
			trans_end = libnd_packet_get_data_end(packet, udp, 0);
		assert(trans_end - ip_end <= plen);
		plen -= (trans_end - ip_end);
		
		if (dir == 0) {
			udp_src_stats[src_port].bytes_out += plen;
                        udp_src_stats[src_port].pkts_out ++;
                        udp_dest_stats[dst_port].bytes_out += plen;
                        udp_dest_stats[dst_port].pkts_out ++;
                } else {
                        udp_src_stats[src_port].bytes_in += plen;
                        udp_src_stats[src_port].pkts_in ++;
                        udp_dest_stats[dst_port].bytes_in += plen;
                        udp_dest_stats[dst_port].pkts_in ++;
                }
		
	}
}

int main(int argc, char *argv[]) {
	LND_Trace *trace;
	LND_PacketIterator pit;
	LND_Packet *packet = NULL;
	LND_BPF_Params bpf_params;
	double ts;
	int opt, i;
	char *filterstring = NULL;

	while ((opt = getopt(argc, argv, "l:f:")) != EOF) {
                switch(opt) {
                        case 'l':
                                local_mac = optarg;
                                break;
                        case 'f':
                                filterstring = optarg;
                                break;
                }
        }

	memset(tcp_src_stats, 0, sizeof(struct port_counter) * 65536);
        memset(tcp_dest_stats, 0, sizeof(struct port_counter) * 65536);
        memset(udp_src_stats, 0, sizeof(struct port_counter) * 65536);
        memset(udp_dest_stats, 0, sizeof(struct port_counter) * 65536);

	if (local_mac != NULL) {
                if (convert_mac_string(local_mac, mac_bytes) < 0) {
                        fprintf(stderr, "Invalid MAC: %s\n", local_mac);
                        return 1;
                }
        } else {
                fprintf(stderr, "Warning: No Local MAC specified (-l)\n");
        }

	libnd_init();
	libnd_plugin_init();

	eth = libnd_proto_registry_find(LND_PROTO_LAYER_LINK, DLT_EN10MB);
	if (!eth)
		return 1;
	ip = libnd_proto_registry_find(LND_PROTO_LAYER_NET, ETHERTYPE_IP);
	if (!ip)
		return 1;
	ip6 = libnd_proto_registry_find(LND_PROTO_LAYER_TRANS, IPPROTO_IPV6);
	if (!ip6)
		return 1;
	tcp = libnd_proto_registry_find(LND_PROTO_LAYER_TRANS, IPPROTO_TCP);
	if (!tcp)
		return 1;
	udp = libnd_proto_registry_find(LND_PROTO_LAYER_TRANS, IPPROTO_UDP);
	if (!udp)
		return 1;
	icmp = libnd_proto_registry_find(LND_PROTO_LAYER_TRANS, IPPROTO_ICMP);
	if (!icmp)
		return 1;
	bpf = libnd_plugin_find("BPF-Filter");
	if (!bpf)
		return 1;
	
        for (i = optind; i < argc; i++) {
                fprintf(stderr, "%s\n", argv[i]);
		if (! (trace = libnd_trace_new(argv[i]))) {
			fprintf(stderr, "Unable to open trace file: %s\n", argv[i]);
			return 1;
		}
				
		if (filterstring) {
                        LND_Filter *filter = NULL;
                        bpf_params.filter_name = "nd_filter";
                        bpf_params.filter_expr = filterstring;

                        if ((filter = libnd_bpf_new(&bpf_params))) {
                                libnd_trace_add_filter(trace, filter);
                        } else {
                                fprintf(stderr, "Failed to create filter\n");
                                return 1;
                        }

                }
	
		for (libnd_pit_init_mode(&pit, trace, LND_PACKET_IT_AREA_RW); libnd_pit_get(&pit); libnd_pit_next(&pit)) {
			packet = libnd_pit_get(&pit);
			ts = packet->ph.ts.tv_sec + ((packet->ph.ts.tv_usec * 1.0) / 1000000);
			per_packet(packet, ts);
		}
		
		libnd_trace_free(trace);
	
	}		


	for (int i = 0; i < 65536; i++) {

                printf("%u  %lu %lu %lu %lu  %lu %lu %lu %lu  %lu %lu %lu %lu  %lu %lu %lu %lu\n",
                                i,
                                tcp_src_stats[i].pkts_out,
                                tcp_src_stats[i].bytes_out,
                                tcp_src_stats[i].pkts_in,
                                tcp_src_stats[i].bytes_in,
                                tcp_dest_stats[i].pkts_out,
                                tcp_dest_stats[i].bytes_out,
                                tcp_dest_stats[i].pkts_in,
                                tcp_dest_stats[i].bytes_in,
                                udp_src_stats[i].pkts_out,
                                udp_src_stats[i].bytes_out,
                                udp_src_stats[i].pkts_in,
                                udp_src_stats[i].bytes_in,
                                udp_dest_stats[i].pkts_out,
                                udp_dest_stats[i].bytes_out,
                                udp_dest_stats[i].pkts_in,
                                udp_dest_stats[i].bytes_in);

        }


}

		
	
