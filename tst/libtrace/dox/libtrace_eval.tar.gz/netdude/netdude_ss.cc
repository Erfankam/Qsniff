#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <getopt.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>
#include <netinet/ether.h>

#include <libnd.h>
#include <plugins/libnd_bpf.h>
#include "flow_manager/flow_manager.h"

uint8_t mac_bytes[6];
char *local_mac = NULL;
LND_Protocol *eth = NULL;
LND_Protocol *ip = NULL;
LND_Protocol *ip6 = NULL;
LND_Protocol *tcp = NULL;
LND_Protocol *icmp = NULL;
LND_Plugin *bpf = NULL;

void per_packet(LND_Packet *packet, double ts) {
	Flow *f = NULL;
	fm_param_t param;
	struct ether_header *ethhdr = NULL;
	guchar *tcp_end = NULL;
	guchar *ip_end = NULL;
	struct tcphdr *tcphdr = NULL;

	while ((f = fm_expire_next_flow(ts, false)) != NULL) {
		fm_report_summary(f);
	}
	f = NULL;
	memset(&param, 0, sizeof(param));

	
	if (!libnd_packet_has_complete_header(packet, eth, 0))
		return;
	ethhdr = (struct ether_header *)libnd_packet_get_data(packet, eth, 0);
	assert(ethhdr);

	if (memcmp(ethhdr->ether_shost, mac_bytes, 6) == 0)
		param.dir = 0;
	else if (memcmp(ethhdr->ether_dhost, mac_bytes, 6) == 0)
		param.dir = 1;
	else {
		return;
	}

	struct iphdr *iphdr = (struct iphdr *)libnd_packet_get_data(packet, ip, 0);
	if (iphdr) {
		if ((ntohs(iphdr->frag_off) & 0x1fff) != 0)
			return;
		param.ip_version = 4;
		param.src_ip = iphdr->saddr;
		param.dest_ip = iphdr->daddr;
		param.payload_bytes = ntohs(iphdr->tot_len) - (iphdr->ihl * 4);
		ip_end = ((guchar *)iphdr) + (iphdr->ihl * 4);
		
	} 

	if (libnd_packet_has_complete_header(packet, ip6, 0)) {
		struct ip6_hdr *ip6hdr = (struct ip6_hdr *) libnd_packet_get_data(packet, ip6, 0);
		param.ip_version = 6;
		memcpy(param.src_ip6, &ip6hdr->ip6_src, sizeof(param.src_ip6));
		memcpy(param.dest_ip6, &ip6hdr->ip6_dst, sizeof(param.dest_ip6));
		ip_end = ((guchar *)ip6hdr) + sizeof(struct ip6_hdr);
		param.payload_bytes = ntohs(ip6hdr->ip6_plen);
	}
	if (!ip_end)
		return;
	
	/* Ignore ICMP, because libnetdude will give us the TCP header inside
	 * the ICMP payload if we're not careful */
	if (libnd_packet_get_data(packet, icmp, 0))
		return;
	
	if (!libnd_packet_has_complete_header(packet, tcp, 0))
		return;
	tcphdr = (struct tcphdr *)libnd_packet_get_data(packet, tcp, 0);

	param.src_port = ntohs(tcphdr->source);
        param.dest_port = ntohs(tcphdr->dest);
        param.proto = 6;
        param.syn = tcphdr->syn;
        param.ack = tcphdr->ack;
        param.fin = tcphdr->fin;
        param.rst = tcphdr->rst;
	
	tcp_end = ((guchar *)tcphdr) + (tcphdr->doff * 4);
	if (tcp_end > libnd_packet_get_data_end(packet, tcp, 0))
		param.payload_bytes = 0;
	else {
		assert(tcp_end - ip_end <= param.payload_bytes);
		param.payload_bytes -= (tcp_end - ip_end);	
	}
	

	f = fm_match_flow(param);

        if (!f) return;
        fm_update_stats(f, param, ts);
        fm_update_expiry(f, param, ts);
	
}

int main(int argc, char *argv[]) {
	LND_Trace *trace;
	LND_PacketIterator pit;
	LND_Packet *packet = NULL;
	LND_BPF_Params bpf_params;
	double ts;
	int opt, i;
	char *filterstring = NULL;
	Flow *f;

	while ((opt = getopt(argc, argv, "l:f:")) != EOF) {
                switch(opt) {
                        case 'l':
                                local_mac = optarg;
                                break;
                        case 'f':
                                filterstring = optarg;
                                break;
                }
        }

	if (local_mac != NULL) {
                if (convert_mac_string(local_mac, mac_bytes) < 0) {
                        fprintf(stderr, "Invalid MAC: %s\n", local_mac);
                        return 1;
                }
        } else {
                fprintf(stderr, "Warning: No Local MAC specified (-l)\n");
        }

	libnd_init();
	libnd_plugin_init();

	eth = libnd_proto_registry_find(LND_PROTO_LAYER_LINK, DLT_EN10MB);
	if (!eth)
		return 1;
	ip = libnd_proto_registry_find(LND_PROTO_LAYER_NET, ETHERTYPE_IP);
	if (!ip)
		return 1;
	ip6 = libnd_proto_registry_find(LND_PROTO_LAYER_NET, ETHERTYPE_IPV6);
	if (!ip6)
		return 1;
	tcp = libnd_proto_registry_find(LND_PROTO_LAYER_TRANS, IPPROTO_TCP);
	if (!tcp)
		return 1;
	icmp = libnd_proto_registry_find(LND_PROTO_LAYER_TRANS, IPPROTO_ICMP);
	if (!icmp)
		return 1;
	bpf = libnd_plugin_find("BPF-Filter");
	if (!bpf)
		return 1;
	
        for (i = optind; i < argc; i++) {
                fprintf(stderr, "%s\n", argv[i]);
		if (! (trace = libnd_trace_new(argv[i]))) {
			fprintf(stderr, "Unable to open trace file: %s\n", argv[i]);
			return 1;
		}
				
		if (filterstring) {
			LND_Filter *filter = NULL;
			bpf_params.filter_name = "nd_filter";
			bpf_params.filter_expr = filterstring;

			if ((filter = libnd_bpf_new(&bpf_params))) {
				libnd_trace_add_filter(trace, filter);
			} else {
				fprintf(stderr, "Failed to create filter\n");
				return 1;
			}

		}
	
		for (libnd_pit_init_mode(&pit, trace, LND_PACKET_IT_AREA_RW); libnd_pit_get(&pit); libnd_pit_next(&pit)) {
			packet = libnd_pit_get(&pit);
			ts = packet->ph.ts.tv_sec + ((packet->ph.ts.tv_usec * 1.0) / 1000000);
			per_packet(packet, ts);
		}
		
		libnd_trace_free(trace);
	
	}		
	while ((f = fm_expire_next_flow(ts, true)))
		fm_report_summary(f);
}

		
	
