#!/usr/bin/python

import sys
import string
from scapy.all import *
from getopt import *
from ctypes import *
from socket import *

local_mac = ""
filterstring = ""

fmlib = cdll.LoadLibrary("/home/salcock/libcoral/scan_study/libflow_manager.so.1.0")

class Params(Structure):
	_fields_ = [("ip_version", c_ubyte), \
		    ("src_ip", c_uint), \
		    ("src_ip6", c_ubyte * 16), \
		    ("dest_ip", c_uint), \
		    ("dest_ip6", c_ubyte * 16), \
		    ("src_port", c_ushort), \
		    ("dest_port", c_ushort), \
		    ("proto", c_ubyte), \
		    ("dir", c_ubyte), \
		    ("syn", c_bool), \
		    ("ack", c_bool), \
		    ("fin", c_bool), \
		    ("rst", c_bool), \
		    ("payload_bytes", c_uint)]

ts = 0

fmlib.fm_expire_next_flow.restype = c_void_p
fmlib.fm_match_flow.restype = c_void_p

def per_packet(pkt):
	global ts

	ts = pkt.time
	p = Params()

	while 1:
		f = fmlib.fm_expire_next_flow(c_double(ts), False)
		if f == None:
			break
		fmlib.fm_report_summary(f)

	if not pkt.haslayer(Ether):
		return

	if pkt[Ether].src == local_mac:
		p.dir = 0
	elif pkt[Ether].dst == local_mac:
		p.dir = 1
	else:
		return

	ip_len = -1
	rem = -1;

	if pkt.haslayer(IP):
		rem = len(pkt.getlayer(IP))
		ip_len = pkt[IP].len
		p.ip_version = 4
		p.src_ip = cast(inet_aton(pkt[IP].src), POINTER(c_uint)).contents
		p.dest_ip = cast(inet_aton(pkt[IP].dst), POINTER(c_uint)).contents

	if pkt.haslayer(IPv6) and rem == -1:
		rem = len(pkt.getlayer(IPv6))
		ip_len = pkt[IPv6].plen + 40
		p.ip_version = 6
		p.src_ip6 = cast(inet_pton(AF_INET6, pkt[IPv6].src), POINTER(c_ubyte * 16)).contents
		p.dest_ip6 = cast(inet_pton(AF_INET6, pkt[IPv6].dst), POINTER(c_ubyte * 16)).contents

	if not pkt.haslayer(TCP):
		return
	
	if len(pkt.getlayer(TCP)) < 20:
		return
	assert(rem - len(pkt.getlayer(TCP)) < ip_len)

	if ((pkt[TCP].dataofs) == None):
		return

	p.proto = 6
	p.payload_bytes = ip_len - (rem - len(pkt.getlayer(TCP))) - pkt[TCP].dataofs * 4
	p.src_port = pkt[TCP].sport
	p.dest_port = pkt[TCP].dport
	p.syn = (pkt[TCP].flags & 0x02)
	p.ack = (pkt[TCP].flags & 0x10)
	p.fin = (pkt[TCP].flags & 0x01)
	p.rst = (pkt[TCP].flags & 0x04)

	f = fmlib.fm_match_flow(p)
	if (f == None):
		return

	fmlib.fm_update_stats(f, p, c_double(ts))
	fmlib.fm_update_expiry(f, p, c_double(ts))
	return



optlist, args = getopt(sys.argv[1:], "l:f:")

for o, a in optlist:
	if o == "-l":
		local_mac = a
	if o == "-f":
		filterstring = a

if local_mac == "":
	sys.stderr.write("Warning: No local MAC specified (-l)\n")

for arg in args:
	if (filterstring):
		pkts = sniff(store = 0, offline=arg, prn=per_packet, filter=filterstring)
	else:
		pkts = sniff(store = 0, offline=arg, prn=per_packet)


while 1:
	f = fmlib.fm_expire_next_flow(c_double(ts), True)
	if f == None:
		break
	fmlib.fm_report_summary(f)

