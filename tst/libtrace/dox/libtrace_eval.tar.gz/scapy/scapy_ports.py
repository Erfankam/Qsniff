#!/usr/bin/python

import sys
import string
from scapy.all import *
from getopt import *

tcp_src_stats = {} 
tcp_dest_stats = {}
udp_src_stats = {}
udp_dest_stats = {} 
local_mac = ""
filterstring = ""

def per_packet(pkt):

	if not pkt.haslayer(Ether):
		return

	if pkt[Ether].src == local_mac:
		dir = 0
	elif pkt[Ether].dst == local_mac:
		dir = 1
	else:
		return

	ip_len = -1
	rem = -1;

	if pkt.haslayer(IP):
		rem = len(pkt.getlayer(IP))
		ip_len = pkt[IP].len

	if pkt.haslayer(IPv6) and rem != -1:
		rem = len(pkt.getlayer(IPv6))
		ip_len = pkt[IPv6].plen + 40

	if pkt.haslayer(TCP):
		if len(pkt.getlayer(TCP)) < 20:
			return
		assert(rem - len(pkt.getlayer(TCP)) < ip_len)
	
		if ((pkt[TCP].dataofs) == None):
			return
		plen = ip_len - (rem - len(pkt.getlayer(TCP))) - pkt[TCP].dataofs * 4
		if dir == 0:
			tcp_src_stats[pkt[TCP].sport][0] += 1
			tcp_src_stats[pkt[TCP].sport][1] += plen
			tcp_dest_stats[pkt[TCP].dport][0] += 1
			tcp_dest_stats[pkt[TCP].dport][1] += plen
		else:
			tcp_src_stats[pkt[TCP].sport][2] += 1
			tcp_src_stats[pkt[TCP].sport][3] += plen
			tcp_dest_stats[pkt[TCP].dport][2] += 1
			tcp_dest_stats[pkt[TCP].dport][3] += plen

	if pkt.haslayer(UDP):
		if len(pkt.getlayer(UDP)) < 8:
			return
		assert(rem - len(pkt.getlayer(UDP)) < ip_len)
		
		plen = ip_len - (rem - len(pkt.getlayer(UDP))) - 8

		if dir == 0:
			udp_src_stats[pkt[UDP].sport][0] += 1
			udp_src_stats[pkt[UDP].sport][1] += plen
			udp_dest_stats[pkt[UDP].dport][0] += 1
			udp_dest_stats[pkt[UDP].dport][1] += plen
		else:
			udp_src_stats[pkt[UDP].sport][2] += 1
			udp_src_stats[pkt[UDP].sport][3] += plen
			udp_dest_stats[pkt[UDP].dport][2] += 1
			udp_dest_stats[pkt[UDP].dport][3] += plen


for i in range(0, 65536):
	tcp_src_stats[i] = [0,0,0,0]
	udp_src_stats[i] = [0,0,0,0]
	tcp_dest_stats[i] = [0,0,0,0]
	udp_dest_stats[i] = [0,0,0,0]

optlist, args = getopt(sys.argv[1:], "l:f:")

for o, a in optlist:
	if o == "-l":
		local_mac = a
	if o == "-f":
		filterstring = a

if local_mac == "":
	sys.stderr.write("Warning: No local MAC specified (-l)\n")

for arg in args:
	if (filterstring):
		pkts = sniff(store = 0, offline=arg, prn=per_packet, filter=filterstring)
	else:
		pkts = sniff(store = 0, offline=arg, prn=per_packet)


for i in range(0, 65536):
	print "%u  %u %u %u %u  %u %u %u %u  %u %u %u %u  %u %u %u %u" % (\
		i, \
		tcp_src_stats[i][0], \
		tcp_src_stats[i][1], \
		tcp_src_stats[i][2], \
		tcp_src_stats[i][3], \
		tcp_dest_stats[i][0], \
		tcp_dest_stats[i][1], \
		tcp_dest_stats[i][2], \
		tcp_dest_stats[i][3], \
		udp_src_stats[i][0], \
		udp_src_stats[i][1], \
		udp_src_stats[i][2], \
		udp_src_stats[i][3], \
		udp_dest_stats[i][0], \
		udp_dest_stats[i][1], \
		udp_dest_stats[i][2], \
		udp_dest_stats[i][3])
