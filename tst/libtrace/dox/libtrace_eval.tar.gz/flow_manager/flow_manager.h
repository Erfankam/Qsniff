#ifndef FLOW_MANAGER_H_
#define FLOW_MANAGER_H_

#include <list>
#include <map>
#include <inttypes.h>

typedef struct id {

	uint8_t ip_version;

	uint32_t inside_ip;
	uint8_t inside_ip6[16];
	uint32_t outside_ip;
	uint8_t outside_ip6[16];
	uint16_t inside_port;
	uint16_t outside_port;
	uint8_t protocol;

} flow_id_t;

typedef enum {
	FLOW_STATE_UNKNOWN,
	FLOW_STATE_NEW,
	FLOW_STATE_ESTAB,
	FLOW_STATE_HALFCLOSE,
	FLOW_STATE_RESET,
	FLOW_STATE_CLOSE
} flow_state_t;

typedef enum {
	FM_TCP_INACTIVE,
	FM_TCP_SYN_SENT,
	FM_TCP_SYN_ACK_SENT,
	FM_TCP_PARTIAL,
	FM_TCP_CLOSED,
	FM_TCP_ESTABLISHED,
	FM_TCP_RESET
} fm_tcp_state_t;

typedef struct conn_summary {

	double first_ts;
	double last_ts;

	uint8_t orig_dir;

	uint64_t bytes_orig;
	uint64_t bytes_resp;
	uint16_t app_port;

	bool seen_syn;
	bool seen_syn_ack;

	bool seen_fin_orig;
	bool seen_fin_resp;
	bool seen_reset_orig;
	bool seen_reset_resp;

	fm_tcp_state_t orig_state;
	fm_tcp_state_t resp_state;

} conn_summary_t;

typedef struct Flow Flow;
typedef std::list<Flow *> ExpireList;

struct Flow {

	flow_id_t id;
	bool expired;

	bool saw_fin_in;
	bool saw_syn_in;
	bool saw_fin_out;
	bool saw_syn_out;
	bool saw_rst;
	
	double first_ts_in;
	double first_ts_out;

	ExpireList *expire_list;
	double expire_time;
	flow_state_t flow_state;

	conn_summary_t sum;
};


typedef struct fm_param {
	uint8_t ip_version;
	uint32_t src_ip;
	uint8_t src_ip6[16];
	uint32_t dest_ip;
	uint8_t dest_ip6[16];
	uint16_t src_port;
	uint16_t dest_port;
	uint8_t proto;
	uint8_t dir;
	bool syn;
	bool ack;
	bool fin;
	bool rst;

	uint32_t payload_bytes;
} fm_param_t;

extern "C" {
int convert_mac_string(char *string, uint8_t *bytes);
Flow *fm_match_flow(fm_param_t param);
void fm_update_stats(Flow *f, fm_param_t param, double ts);
void fm_update_expiry(Flow *f, fm_param_t param, double ts);
Flow *fm_expire_next_flow(double ts, bool force);
void fm_report_summary(Flow *f);
}

#endif
