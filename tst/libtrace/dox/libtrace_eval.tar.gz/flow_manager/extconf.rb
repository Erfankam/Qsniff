require 'mkmf'
CONFIG['LDSHARED'] = "g++ -shared"
create_makefile("rubyFM")
