#include "ruby.h"
#include "flow_manager.h"

VALUE rubyFM;


static VALUE report(VALUE self, VALUE flow) {
	Flow *f;
	Data_Get_Struct(flow, Flow, f);
	fm_report_summary(f);

	return Qnil;
}

VALUE match_flow(VALUE self, VALUE param) {
	fm_param_t *p;
	Flow *f;
	Data_Get_Struct(param, fm_param_t, p);

	f = fm_match_flow(*p);
	if (f == NULL)
		return Qnil;
	return Data_Wrap_Struct(rubyFM, 0, 0, f);
}

VALUE update_stats(VALUE self, VALUE flow, VALUE param, VALUE ts) {

	Flow *f;
	fm_param_t *p;

	Data_Get_Struct(flow, Flow, f);
	Data_Get_Struct(param, fm_param_t, p);

	fm_update_stats(f, *p, NUM2DBL(ts));
	return Qnil;
}

VALUE update_expiry(VALUE self, VALUE flow, VALUE param, VALUE ts) {
	Flow *f;
	fm_param_t *p;
	Data_Get_Struct(flow, Flow, f);
	Data_Get_Struct(param, fm_param_t, p);

	fm_update_expiry(f, *p, NUM2DBL(ts));
	return Qnil;
}
	
VALUE expire_next(VALUE self, VALUE ts, VALUE force) {

	Flow *f;
	
	f = fm_expire_next_flow(NUM2DBL(ts), (bool)(FIX2INT(force)));
	if (f == NULL)
		return Qnil;
	
	return Data_Wrap_Struct(rubyFM, 0, 0, f);	
}

VALUE init_param(VALUE self, VALUE ip_v, VALUE ip_src, VALUE ip_dst, 
		VALUE src_port, VALUE dst_port, VALUE proto, VALUE syn,
		VALUE ack, VALUE fin, VALUE rst, VALUE plen, VALUE dir) {

	fm_param_t *p;
	p = ALLOC(fm_param_t);

	p->ip_version = FIX2INT(ip_v);
	p->src_port = FIX2INT(src_port);
	p->dest_port = FIX2INT(dst_port);
	p->proto = FIX2INT(proto);
	p->syn = syn;
	p->rst = rst;
	p->fin = fin;
	p->ack = ack;
	p->dir = FIX2INT(dir);
	p->payload_bytes = FIX2INT(plen);

	if (p->ip_version == 4) {
		p->src_ip = *((uint32_t *)STR2CSTR(ip_src));
		p->dest_ip = *((uint32_t *)STR2CSTR(ip_dst));
	}

	if (p->ip_version == 6) {
		memcpy(p->src_ip6, STR2CSTR(ip_src), sizeof(p->src_ip6));
		memcpy(p->dest_ip6, STR2CSTR(ip_dst), sizeof(p->dest_ip6));
	}


	return Data_Wrap_Struct(rubyFM, 0, free, p);
}

extern "C" {

void Init_rubyFM() {
	rubyFM = rb_define_class("RubyFM", rb_cObject);
	rb_define_method(rubyFM, "rubyfm_report_summary", RUBY_METHOD_FUNC(report), 1);
	rb_define_method(rubyFM, "rubyfm_match_flow", RUBY_METHOD_FUNC(match_flow), 1);
	rb_define_method(rubyFM, "rubyfm_update_stats", RUBY_METHOD_FUNC(update_stats), 3);
	rb_define_method(rubyFM, "rubyfm_update_expiry", RUBY_METHOD_FUNC(update_expiry), 3);
	rb_define_method(rubyFM, "rubyfm_expire_next", RUBY_METHOD_FUNC(expire_next), 2);
	rb_define_method(rubyFM, "rubyfm_init_param", RUBY_METHOD_FUNC(init_param), 12);
}

} // extern "C"
