#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>

#include "flow_manager.h"

#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

/* This is a trace-processing-library agnostic version of libflowmanager,
 * designed to be used with the TCP scan study we replicated for comparing
 * libtrace with other trace processing libraries */

/* Only care about TCP for this study */

ExpireList expire_tcp_syn;
ExpireList expire_tcp_estab;
ExpireList expire_now;

struct flow_cmp {

	bool operator() (const flow_id_t &a, const flow_id_t &b) const {
		if (a.ip_version < b.ip_version)
			return true;
		if (a.ip_version > b.ip_version)
			return false;

		if (a.ip_version == 4) {
			if (a.inside_ip < b.inside_ip)
				return true;
			if (a.inside_ip > b.inside_ip)
				return false;
			if (a.outside_ip < b.outside_ip)
				return true;
			if (a.outside_ip > b.outside_ip)
				return false;
		}

		if (a.ip_version == 6) {
			for (int i = 0; i < 16; i++) {
				if (a.inside_ip6[i] < b.inside_ip6[i])
					return true;
				if (a.inside_ip6[i] > b.inside_ip6[i])
					return false;
			}
			for (int i = 0; i < 16; i++) {
				if (a.outside_ip6[i] < b.outside_ip6[i])
					return true;
				if (a.outside_ip6[i] > b.outside_ip6[i])
					return false;
			}
		}

		if (a.inside_port < b.inside_port)
			return true;
		if (a.inside_port > b.inside_port)
			return false;
		if (a.outside_port < b.outside_port)
			return true;
		if (a.outside_port > b.outside_port)
			return false;
		if (a.protocol < b.protocol)
			return true;
		if (a.protocol > b.protocol)
			return false;
		return false;
	}

};

typedef std::map<flow_id_t, ExpireList::iterator, flow_cmp> FlowMap;
FlowMap active_flows;

int convert_mac_string(char *string, uint8_t *bytes) {

	uint32_t digits[6];

	if (sscanf(string, "%x:%x:%x:%x:%x:%x", &(digits[0]),
			&(digits[1]), &(digits[2]), &(digits[3]),
			&(digits[4]), &(digits[5])) != 6)
		return -1;
	
	for (int i = 0; i < 6; i++) {

		if (digits[i] > 255)
			return -1;
		bytes[i] = (uint8_t)digits[i];
	}

	return 0;

}

static void init_summary(conn_summary_t *s, uint8_t dir, uint32_t src_ip,
		uint32_t dest_ip, uint16_t dest_port) {

	s->first_ts = 0;
	s->last_ts = 0;

	s->orig_dir = dir;

	s->app_port = dest_port;
	s->seen_syn = false;
	s->seen_syn_ack = false;
	s->seen_fin_orig = false;
	s->seen_fin_resp = false;
	s->seen_reset_orig = false;
	s->seen_reset_resp = false;
	s->bytes_orig = 0;
	s->bytes_resp = 0;

	s->orig_state = FM_TCP_INACTIVE;
	s->resp_state = FM_TCP_INACTIVE;
}

static const char *application_string(uint16_t port) {
	
	char foo[1000];

	if (port == 80)
		return "http";
	if (port == 443)
		return "https";
	if (port == 25)
		return "smtp";
	
	snprintf(foo, 999, "%u", port);
	return foo;

}

/* Matches Bro's behaviour exactly */
static const char *connection_state(conn_summary_t s) {

	if (s.resp_state == FM_TCP_RESET) {
		if (s.orig_state == FM_TCP_SYN_SENT || 
				s.orig_state == FM_TCP_SYN_ACK_SENT ||
				(s.orig_state == FM_TCP_RESET && s.bytes_orig == 0
				&& s.bytes_resp == 0))
			return "REJ";
		else if (s.orig_state == FM_TCP_INACTIVE || s.orig_state == FM_TCP_PARTIAL)
			return "RSTRH";
		else
			return "RSTR";
	} else if (s.orig_state == FM_TCP_RESET) {
		if (s.resp_state == FM_TCP_INACTIVE || s.resp_state == FM_TCP_PARTIAL)
			return "RSTOS0";
		else
			return "RST0";
	} else if (s.resp_state == FM_TCP_CLOSED && s.orig_state == FM_TCP_CLOSED) {
		return "SF";
	} else if (s.orig_state == FM_TCP_CLOSED) {
		if (s.resp_state == FM_TCP_INACTIVE || s.resp_state == FM_TCP_PARTIAL)
			return "SH";
		else
			return "S2";
	} else if (s.resp_state == FM_TCP_CLOSED) {
		if (s.orig_state == FM_TCP_INACTIVE || s.orig_state == FM_TCP_PARTIAL)
			return "SHR";
		else
			return "S3";
	} else if (s.orig_state == FM_TCP_SYN_SENT && s.resp_state == FM_TCP_INACTIVE) {
		return "S0";
	} else if (s.orig_state == FM_TCP_ESTABLISHED && s.resp_state == FM_TCP_ESTABLISHED) {
		return "S1";
	} 
	return "OTH";

}

/* This one was written using my own interpretation of the connection classes,
 * so differs quite significantly from Bro... */
static const char *old_connection_state(conn_summary_t s) {


	if (!s.seen_syn) {
		if (s.seen_syn_ack && s.seen_reset_resp)
			return "RSTRH";
		if (s.seen_syn_ack && s.seen_fin_resp)
			return "SHR";
		return "OTH";
	}

	if (!s.seen_syn_ack) {
		if (s.seen_reset_resp)
			return "REJ";
		if (s.seen_reset_orig)
			return "RSTOS0";
		if (s.seen_fin_orig)
			return "SH";
		if (s.seen_fin_resp)
			return "SHR-SA";
		return "S0";
	}

	/* Assume connection established */

	if (s.seen_reset_resp)
		return "RSTR";
	if (s.seen_reset_orig)
		return "RSTO";
	
	if (s.seen_fin_orig && s.seen_fin_resp)
		return "SF";
	if (s.seen_fin_orig)
		return "S2";
	if (s.seen_fin_resp)
		return "S3";
	
	return "S1";

}

void fm_report_summary(Flow *f) {

	printf("%.6f %.6f ", f->sum.first_ts, f->sum.last_ts - f->sum.first_ts);
	
	if (f->id.ip_version == 4) {
		struct in_addr in;
		in.s_addr = f->id.inside_ip;
		printf("%s ", inet_ntoa(in));
		in.s_addr = f->id.outside_ip;
		printf("%s ", inet_ntoa(in));

	} else if (f->id.ip_version == 6) {
		char res[INET6_ADDRSTRLEN];

		if (inet_ntop(AF_INET6, f->id.inside_ip6, res, INET6_ADDRSTRLEN) == NULL)
			printf("BAD_IP6 ");
		else
			printf("%s ", res);
		if (inet_ntop(AF_INET6, f->id.outside_ip6, res, INET6_ADDRSTRLEN) == NULL)
			printf("BAD_IP6 ");
		else
			printf("%s ", res);

	} else {
		printf("NA NA ");
	}
	printf("%s ", application_string(f->sum.app_port));
	printf("%u %u ", f->id.inside_port, f->id.outside_port);
	printf("%lu %lu ", f->sum.bytes_orig, f->sum.bytes_resp);
	printf("%s ", old_connection_state(f->sum));

	if (f->sum.orig_dir == 0)
		printf("L\n");
	else
		printf("R\n");

	free(f);
}

Flow *fm_match_flow(fm_param_t param) {

	flow_id_t pkt_id;
	Flow *f = NULL;

	if (param.proto != 6)
		return NULL;
	
	if (param.src_port == 0 || param.dest_port == 0)
		return NULL;
	
	pkt_id.protocol = param.proto;
	pkt_id.ip_version = param.ip_version;

	if (param.dir == 0) {
		if (param.ip_version == 4) {
			pkt_id.inside_ip = param.src_ip;
			pkt_id.outside_ip = param.dest_ip;
		} else if (param.ip_version == 6) {
			memcpy(pkt_id.inside_ip6, param.src_ip6, 16);
			memcpy(pkt_id.outside_ip6, param.dest_ip6, 16);
		}
		pkt_id.inside_port = param.src_port;
		pkt_id.outside_port = param.dest_port;
	} else if (param.dir == 1) {
		if (param.ip_version == 4) {
			pkt_id.outside_ip = param.src_ip;
			pkt_id.inside_ip = param.dest_ip;
		} else if (param.ip_version == 6) {
			memcpy(pkt_id.outside_ip6, param.src_ip6, 16);
			memcpy(pkt_id.inside_ip6, param.dest_ip6, 16);
		}
		pkt_id.outside_ip = param.src_ip;
		pkt_id.inside_ip = param.dest_ip;
		pkt_id.outside_port = param.src_port;
		pkt_id.inside_port = param.dest_port;
	} else {
		return NULL;
	}

	FlowMap::iterator i = active_flows.find(pkt_id);

	if (i != active_flows.end()) {
		f = *(i->second);

		return f;
	}
	
	f = (Flow *)malloc(sizeof(Flow));

	f->flow_state = FLOW_STATE_UNKNOWN;
	f->expire_time = 0.0;
	f->saw_rst = false;
	f->expired = false;
	f->first_ts_in = 0.0;
	f->first_ts_out = 0.0;
	f->saw_fin_in = false;
	f->saw_syn_in = false;
	f->saw_fin_out = false;
	f->saw_syn_out = false;
	f->id = pkt_id;

	init_summary(&(f->sum), param.dir, param.src_ip, param.dest_ip, 
			param.dest_port);

	f->expire_list = &expire_tcp_syn;
	expire_tcp_syn.push_front(f);
	
	
	ExpireList::iterator it;
	active_flows[pkt_id] =  expire_tcp_syn.begin();;


	return f;
}

static void update_tcp_state(conn_summary_t *s, fm_param_t param) {

	fm_tcp_state_t curr;

	if (param.dir == s->orig_dir)
		curr = s->orig_state;
	else
		curr = s->resp_state;

	if (curr == FM_TCP_INACTIVE && param.syn && !param.ack)
		curr = FM_TCP_SYN_SENT;
	else if (curr == FM_TCP_INACTIVE && param.syn && param.ack)
		curr = FM_TCP_SYN_ACK_SENT;
	else if (curr == FM_TCP_INACTIVE && param.payload_bytes != 0)
		curr = FM_TCP_PARTIAL;
	else if (param.fin)
		curr = FM_TCP_CLOSED;
	else if (param.rst)
		curr = FM_TCP_RESET;

	if (param.dir == s->orig_dir)
		s->orig_state = curr;
	else
		s->resp_state = curr;
	
	if (s->orig_state == FM_TCP_SYN_SENT && s->resp_state == FM_TCP_SYN_ACK_SENT) {
		s->orig_state = FM_TCP_ESTABLISHED;
		s->resp_state = FM_TCP_ESTABLISHED;
	}

	if (s->resp_state == FM_TCP_SYN_SENT && s->orig_state == FM_TCP_SYN_ACK_SENT) {
		s->orig_state= FM_TCP_ESTABLISHED;
		s->resp_state = FM_TCP_ESTABLISHED;
	}

}

void fm_update_stats(Flow *f, fm_param_t param, double ts) {

	if (f == NULL)
		return;

	if (param.dir == f->sum.orig_dir) {
		f->sum.bytes_orig += param.payload_bytes;
	}
	else {
		f->sum.bytes_resp += param.payload_bytes;
	}
	if (f->sum.first_ts == 0)
		f->sum.first_ts = ts;
	f->sum.last_ts = ts;

	if (param.syn && !param.ack && param.dir == f->sum.orig_dir)
		f->sum.seen_syn = true;
	if (param.syn && param.ack && param.dir != f->sum.orig_dir)
		f->sum.seen_syn_ack = true;
	
	if (param.fin && f->sum.orig_dir == param.dir)
		f->sum.seen_fin_orig = true;
	if (param.fin && f->sum.orig_dir != param.dir)
		f->sum.seen_fin_resp = true;
	if (param.rst && f->sum.orig_dir == param.dir)
		f->sum.seen_reset_orig = true;
	if (param.rst && f->sum.orig_dir != param.dir)
		f->sum.seen_reset_resp = true;

	
	update_tcp_state(&f->sum, param);

}

void fm_update_expiry(Flow *f, fm_param_t param, double ts) {

	if (param.fin) {
		if (param.dir == 0)
			f->saw_fin_out = true;
		else
			f->saw_fin_in = true;

		if (f->saw_fin_out && f->saw_fin_in)
			f->flow_state = FLOW_STATE_CLOSE;
		else if (f->saw_fin_out || f->saw_fin_in)
			f->flow_state = FLOW_STATE_HALFCLOSE;
	}

	if (param.syn) {
		if (param.dir == 0)
			f->saw_syn_out = true;
		else
			f->saw_syn_in = true;
		if (f->saw_syn_out && f->saw_syn_in)
			f->flow_state = FLOW_STATE_ESTAB;
		else if (f->saw_syn_out || f->saw_syn_in)
			f->flow_state = FLOW_STATE_NEW;
	}

	if (param.rst) {
		f->saw_rst = true;
		f->flow_state = FLOW_STATE_RESET;
	}

	ExpireList *exp_list = NULL;

	switch(f->flow_state) {
		case FLOW_STATE_RESET:
		case FLOW_STATE_CLOSE:
			f->expire_time = ts;
			exp_list = &expire_now;
			break;
		case FLOW_STATE_NEW:
		case FLOW_STATE_HALFCLOSE:
			f->expire_time = ts + 240.0;
			exp_list = &expire_tcp_syn;
			break;
		case FLOW_STATE_ESTAB:
		case FLOW_STATE_UNKNOWN:
			f->expire_time = ts + 7440.0;
			exp_list = &expire_tcp_estab;
			break;
	}

	assert(exp_list);

	FlowMap::iterator it;

	it = active_flows.find(f->id);
	assert(it != active_flows.end());

	//f->expire_list->erase(active_flows[f->id]);
	f->expire_list->erase(it->second);
	f->expire_list = exp_list;
	exp_list->push_front(f);
	//active_flows[f->id] = exp_list->begin();
	it->second = exp_list->begin();

}

static Flow *get_next_expired(ExpireList *expire, double ts, bool force) {
	ExpireList::iterator i;
	Flow *f;

	if (expire->empty())
		return NULL;

	f = expire->back();
	if (f->expire_time <= ts)
		f->expired = true;
	if (force || f->expired) {
		expire->pop_back();
		active_flows.erase(f->id);
		return f;
	}

	return NULL;
}

Flow *fm_expire_next_flow(double ts, bool force) {

	Flow *f;

	f = get_next_expired(&expire_now, ts, force);
	if (f)
		return f;
	f = get_next_expired(&expire_tcp_syn, ts, force);
	if (f)
		return f;
	return get_next_expired(&expire_tcp_estab, ts, force);
	

}
