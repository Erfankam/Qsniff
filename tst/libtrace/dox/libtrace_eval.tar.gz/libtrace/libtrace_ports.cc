#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <getopt.h>

#include <libtrace.h>
uint8_t mac_bytes[6];
char *local_mac = NULL;

struct port_counter {
	uint64_t bytes_in;
	uint64_t bytes_out;
	uint64_t pkts_in;
	uint64_t pkts_out;
};

struct port_counter tcp_src_stats[65536];
struct port_counter tcp_dest_stats[65536];
struct port_counter udp_src_stats[65536];
struct port_counter udp_dest_stats[65536];

int convert_mac_string(char *string, uint8_t *bytes) {

        uint32_t digits[6];

        if (sscanf(string, "%x:%x:%x:%x:%x:%x", &(digits[0]),
                        &(digits[1]), &(digits[2]), &(digits[3]),
                        &(digits[4]), &(digits[5])) != 6)
                return -1;

        for (int i = 0; i < 6; i++) {

                if (digits[i] > 255)
                        return -1;
                bytes[i] = (uint8_t)digits[i];
        }

        return 0;

}


void per_packet(libtrace_packet_t *packet) {

	uint8_t *src_mac = NULL;
	uint8_t *dest_mac = NULL;
	uint8_t dir = 2;
	void *transport;	
	uint8_t proto;
	uint32_t rem, plen;
	uint16_t src_port, dst_port;

	src_mac = trace_get_source_mac(packet);
	dest_mac = trace_get_destination_mac(packet);

	if (!src_mac || !dest_mac) {
		return;
	}

	if (memcmp(src_mac, mac_bytes, 6) == 0)
                dir = 0;
        else if (memcmp(dest_mac, mac_bytes, 6) == 0)
                dir = 1;
        else { 
                return;
	}
	transport = trace_get_transport(packet, &proto, &rem);

	if (transport == NULL || rem == 0) {
		return;
	}
	
	src_port = trace_get_source_port(packet);
	dst_port = trace_get_destination_port(packet);
	plen = trace_get_payload_length(packet);

	if (dir == 0 && proto == TRACE_IPPROTO_TCP && rem >= sizeof(libtrace_tcp_t)) {
		tcp_src_stats[src_port].bytes_out += plen;
		tcp_src_stats[src_port].pkts_out ++;
		tcp_dest_stats[dst_port].bytes_out += plen;
		tcp_dest_stats[dst_port].pkts_out ++;
	} else if (proto == TRACE_IPPROTO_TCP && rem >= sizeof(libtrace_tcp_t)) {
		tcp_src_stats[src_port].bytes_in += plen;
		tcp_src_stats[src_port].pkts_in ++;
		tcp_dest_stats[dst_port].bytes_in += plen;
		tcp_dest_stats[dst_port].pkts_in ++;
	} else if (dir == 0 && proto == TRACE_IPPROTO_UDP && rem >= sizeof(libtrace_udp_t)) {
		udp_src_stats[src_port].bytes_out += plen;
		udp_src_stats[src_port].pkts_out ++;
		udp_dest_stats[dst_port].bytes_out += plen;
		udp_dest_stats[dst_port].pkts_out ++;
	} else if (proto == TRACE_IPPROTO_UDP && rem >= sizeof(libtrace_udp_t)) {
		udp_src_stats[src_port].bytes_in += plen;
		udp_src_stats[src_port].pkts_in ++;
		udp_dest_stats[dst_port].bytes_in += plen;
		udp_dest_stats[dst_port].pkts_in ++;
	}
}

int main (int argc, char *argv[]) {

	libtrace_t *trace;
	libtrace_packet_t *packet;
	int opt, i;
	char *filterstring = NULL;
	libtrace_filter_t *filter = NULL;

	while ((opt = getopt(argc, argv, "l:f:")) != EOF) {
		switch(opt) {
			case 'l':
				local_mac = optarg;
				break;
			case 'f':
				filterstring = optarg;
				break;
		}
	}

	if (filterstring)
		filter = trace_create_filter(filterstring);
	
	packet = trace_create_packet();

	memset(tcp_src_stats, 0, sizeof(struct port_counter) * 65536);
	memset(tcp_dest_stats, 0, sizeof(struct port_counter) * 65536);
	memset(udp_src_stats, 0, sizeof(struct port_counter) * 65536);
	memset(udp_dest_stats, 0, sizeof(struct port_counter) * 65536);

	if (local_mac != NULL) {
                if (convert_mac_string(local_mac, mac_bytes) < 0) {
                        fprintf(stderr, "Invalid MAC: %s\n", local_mac);
                        return 1;
                }
        } else {
                fprintf(stderr, "Warning: No Local MAC specified (-l)\n");
        }


	for (i = optind; i < argc; i++) {
		trace = trace_create(argv[i]);

		if (trace_is_err(trace)) {
			trace_perror(trace, "Opening trace file");
			return 1;
		}

		if (filter && trace_config(trace, TRACE_OPTION_FILTER, filter) == -1) {
			trace_perror(trace, "Configuring trace");
			trace_destroy(trace);
			return 1;
		}
		if (trace_start(trace)) {
			trace_perror(trace, "Starting trace");
			trace_destroy(trace);
			return 1;
		}

		while (trace_read_packet(trace, packet) > 0) {
			per_packet(packet);
		}

		if (trace_is_err(trace)) {
			trace_perror(trace, "Reading packets");
			trace_destroy(trace);
			return 1;
		}

		trace_destroy(trace);
	}

	for (int i = 0; i < 65536; i++) {

		printf("%u  %lu %lu %lu %lu  %lu %lu %lu %lu  %lu %lu %lu %lu  %lu %lu %lu %lu\n",
				i, 
				tcp_src_stats[i].pkts_out, 
				tcp_src_stats[i].bytes_out,
				tcp_src_stats[i].pkts_in, 
				tcp_src_stats[i].bytes_in,
				tcp_dest_stats[i].pkts_out, 
				tcp_dest_stats[i].bytes_out,
				tcp_dest_stats[i].pkts_in, 
				tcp_dest_stats[i].bytes_in,
				udp_src_stats[i].pkts_out, 
				udp_src_stats[i].bytes_out,
				udp_src_stats[i].pkts_in, 
				udp_src_stats[i].bytes_in,
				udp_dest_stats[i].pkts_out, 
				udp_dest_stats[i].bytes_out,
				udp_dest_stats[i].pkts_in, 
				udp_dest_stats[i].bytes_in);

	}

	trace_destroy_packet(packet);
	return 0;

}
