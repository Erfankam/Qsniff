#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <getopt.h>

#include <libtrace.h>
#include "flow_manager/flow_manager.h"

uint8_t mac_bytes[6];
char *local_mac = NULL;

void per_packet(libtrace_packet_t *packet, double ts) {

	Flow *f = NULL;
	fm_param_t param;
	libtrace_ip_t *ip = NULL;
	libtrace_ip6_t *ip6 = NULL;
	libtrace_tcp_t *tcp = NULL;
	void *ptr;
	uint16_t l3_type = 0;
	uint8_t *src_mac = NULL;
	uint8_t *dest_mac = NULL;

	while ((f = fm_expire_next_flow(ts, false)) != NULL) {
		fm_report_summary(f);
	}
	f = NULL;
	memset(&param, 0, sizeof(param));

	src_mac = trace_get_source_mac(packet);
	dest_mac = trace_get_destination_mac(packet);

	if (!src_mac || !dest_mac)
		return;

	if (memcmp(src_mac, mac_bytes, 6) == 0)
                param.dir = 0;
        else if (memcmp(dest_mac, mac_bytes, 6) == 0)
                param.dir = 1;
        else
                return;
	
	
	ptr = trace_get_layer3(packet, &l3_type, NULL);
	if (ptr == NULL) return;

	if (l3_type == TRACE_ETHERTYPE_IP) {
		ip = (libtrace_ip_t *)ptr;
		param.ip_version = 4;
		param.src_ip = ip->ip_src.s_addr;		
		param.dest_ip = ip->ip_dst.s_addr;
	} else if (l3_type == TRACE_ETHERTYPE_IPV6) {
		ip6 = (libtrace_ip6_t *)ptr;
		param.ip_version = 6;
		memcpy(param.src_ip6, ip6->ip_src.s6_addr, sizeof(param.src_ip6));
		memcpy(param.dest_ip6, ip6->ip_dst.s6_addr, sizeof(param.dest_ip6));
	} else {
		return;
	}

	param.src_port = trace_get_source_port(packet);
	param.dest_port = trace_get_destination_port(packet);

	tcp = trace_get_tcp(packet);
	if (tcp == NULL) return;
	param.proto = TRACE_IPPROTO_TCP;
	param.syn = tcp->syn;
	param.ack = tcp->ack;
	param.fin = tcp->fin;
	param.rst = tcp->rst;

	param.payload_bytes = trace_get_payload_length(packet);

	f = fm_match_flow(param);

	if (!f) return;
	
	fm_update_stats(f, param, ts);
	fm_update_expiry(f, param, ts);


}

int main (int argc, char *argv[]) {

	libtrace_t *trace;
	libtrace_packet_t *packet;
	double ts;
	int opt, i;
	char *filterstring = NULL;
	libtrace_filter_t *filter = NULL;
	Flow *f;

	while ((opt = getopt(argc, argv, "l:f:")) != EOF) {
		switch(opt) {
			case 'l':
				local_mac = optarg;
				break;
			case 'f':
				filterstring = optarg;
				break;
		}
	}

	if (filterstring)
		filter = trace_create_filter(filterstring);
	
	packet = trace_create_packet();

	if (local_mac != NULL) {
                if (convert_mac_string(local_mac, mac_bytes) < 0) {
                        fprintf(stderr, "Invalid MAC: %s\n", local_mac);
                        return 1;
                }
        } else {
                fprintf(stderr, "Warning: No Local MAC specified (-l)\n");
        }


	for (i = optind; i < argc; i++) {
		trace = trace_create(argv[i]);

		if (trace_is_err(trace)) {
			trace_perror(trace, "Opening trace file");
			return 1;
		}

		if (filter && trace_config(trace, TRACE_OPTION_FILTER, filter) == -1) {
			trace_perror(trace, "Configuring trace");
			trace_destroy(trace);
			return 1;
		}
		if (trace_start(trace)) {
			trace_perror(trace, "Starting trace");
			trace_destroy(trace);
			return 1;
		}

		while (trace_read_packet(trace, packet) > 0) {
			ts = trace_get_seconds(packet);
			per_packet(packet, ts);
		}

		if (trace_is_err(trace)) {
			trace_perror(trace, "Reading packets");
			trace_destroy(trace);
			return 1;
		}

		trace_destroy(trace);
	}

	trace_destroy_packet(packet);
	while ((f = fm_expire_next_flow(ts, true)))
		fm_report_summary(f);

}
