#!/usr/bin/env ruby

require 'RubyLibtrace'
require 'getoptlong'
require '/home/salcock/libcoral/scan_study/flow_manager/rubyFM'

$ts = 0
$mac_bytes = ""

$fm = RubyFM.new

def per_packet(pkt)
	
	l2 = pkt.layer2
	dest_mac = l2.data[0, 6]
	src_mac = l2.data[6, 6]
	dir = 2
	$ts = pkt.seconds

	while ((f =$fm.rubyfm_expire_next($ts, 0)) != nil) do
		$fm.rubyfm_report_summary(f)
	end

	f = nil

	if dest_mac == $mac_bytes:
		dir = 1
	elsif src_mac == $mac_bytes:
		dir = 0
	else
		return
	end

	plen = 0

	l3 = pkt.layer3
	if l3 == nil
		return
	end
	
	if l3.ethertype == 0x0800
		ip = pkt.ip
		ip_src = ip.src_prefix.addr
		ip_dst = ip.dst_prefix.addr
		ip_v = 4
	elsif l3.ethertype == 0x08DD
		ip6 = pkt.ip6
		ip_src = ip6.src_prefix.addr
		ip_dst = ip6.dst_prefix.addr
		ip_v = 6
	else
		return
	end

	l4 = pkt.transport
	if (l4 == nil or l4.proto != 6)
		return
	end

	plen = pkt.payload_len
	
	tcp = pkt.tcp
	if tcp == nil
		return
	end
	
	if tcp.urg_ptr == nil
		return
	end

	src_port = tcp.src_port
	dst_port = tcp.dst_port

	param = $fm.rubyfm_init_param(ip_v, ip_src, ip_dst, src_port, dst_port, 6, tcp.syn?, tcp.ack?, tcp.fin?, tcp.rst?, plen, dir)

	f = $fm.rubyfm_match_flow(param)
	if f == nil
		return
	end
	$fm.rubyfm_update_stats(f, param, $ts)
	$fm.rubyfm_update_expiry(f, param, $ts)
end

filterstring = nil
local_mac = nil

opts = GetoptLong.new(['--local', '-l', GetoptLong::OPTIONAL_ARGUMENT],
	['--filter', '-f', GetoptLong::OPTIONAL_ARGUMENT])

opts.each do |opt, arg|
	case opt
		when '--filter'
			filterstring = arg
		when '--local'
			local_mac = arg
	end
end

if local_mac == nil
	$stderr.puts "Warning: No local MAC specified (-l)"
else
	bytes = (local_mac.split(':'))
	bytes.each do |b|
		$mac_bytes << (b.hex)
	end
end

ARGV.each do |tracefile|
	$stderr.print tracefile, "\n"

	begin
		trace = Trace.new(tracefile)
		if filterstring != nil:
			trace.conf_filter(filterstring)
		end
		trace.start
	rescue LibtraceError => lterr
		$stderr.print "Error creating trace:" + lterr
	end

	trace.each_packet do |pkt|
		per_packet(pkt)
	end
		
end

$fm.rubyfm_expire_next($ts, 1) 
