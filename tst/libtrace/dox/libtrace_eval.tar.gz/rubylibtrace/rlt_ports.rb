#!/usr/bin/env ruby

require 'RubyLibtrace'
require 'getoptlong'

$tcp_src_stats = []
$tcp_dest_stats = []
$udp_src_stats = []
$udp_dest_stats = []
$mac_bytes = ""

def per_packet(pkt)
	
	l2 = pkt.layer2
	dest_mac = l2.data[0, 6]
	src_mac = l2.data[6, 6]

	if dest_mac == $mac_bytes:
		dir = 1
	elsif src_mac == $mac_bytes:
		dir = 0
	else
		return
	end

	plen = 0

	l4 = pkt.transport
	if (l4 == nil)
		return
	end

	plen = pkt.payload_len

	if l4.proto == 6:
		tcp = pkt.tcp
		if tcp == nil or tcp.data.size < 20:
			return
		end

		if dir == 0 and tcp.src_port != nil and tcp.dst_port != nil
			$tcp_src_stats[tcp.src_port][0] += 1
			$tcp_src_stats[tcp.src_port][1] += plen
			$tcp_dest_stats[tcp.dst_port][0] += 1
			$tcp_dest_stats[tcp.dst_port][1] += plen
		elsif tcp.src_port != nil and tcp.dst_port != nil		
			$tcp_src_stats[tcp.src_port][2] += 1
			$tcp_src_stats[tcp.src_port][3] += plen
			$tcp_dest_stats[tcp.dst_port][2] += 1
			$tcp_dest_stats[tcp.dst_port][3] += plen
		end
	end

	if l4.proto == 17:
		udp = pkt.udp
		if !udp or udp.data.size < 8:
			return
		end

		if dir == 0 and udp.src_port != nil and udp.dst_port != nil
			$udp_src_stats[udp.src_port][0] += 1
			$udp_src_stats[udp.src_port][1] += plen
			$udp_dest_stats[udp.dst_port][0] += 1
			$udp_dest_stats[udp.dst_port][1] += plen
		elsif udp.src_port != nil and udp.dst_port != nil		
			$udp_src_stats[udp.src_port][2] += 1
			$udp_src_stats[udp.src_port][3] += plen
			$udp_dest_stats[udp.dst_port][2] += 1
			$udp_dest_stats[udp.dst_port][3] += plen
		end
	end

end

for i in 0...65536
	$tcp_src_stats.push([0,0,0,0])
	$tcp_dest_stats.push([0,0,0,0])
	$udp_src_stats.push([0,0,0,0])
	$udp_dest_stats.push([0,0,0,0])
end

filterstring = nil
local_mac = nil

opts = GetoptLong.new(['--local', '-l', GetoptLong::OPTIONAL_ARGUMENT],
	['--filter', '-f', GetoptLong::OPTIONAL_ARGUMENT])

opts.each do |opt, arg|
	case opt
		when '--filter'
			filterstring = arg
		when '--local'
			local_mac = arg
	end
end

if local_mac == nil
	$stderr.puts "Warning: No local MAC specified (-l)"
else
	bytes = (local_mac.split(':'))
	bytes.each do |b|
		$mac_bytes << (b.hex)
	end
end

ARGV.each do |tracefile|
	$stderr.print tracefile, "\n"

	begin
		trace = Trace.new(tracefile)
		if filterstring != nil:
			trace.conf_filter(filterstring)
		end
		trace.start
	rescue LibtraceError => lterr
		$stderr.print "Error creating trace:" + lterr
	end

	trace.each_packet do |pkt|
		per_packet(pkt)
	end
		
end


for i in 0...65536 
	printf("%u  %u %u %u %u  %u %u %u %u  %u %u %u %u  %u %u %u %u\n",
			i,
			$tcp_src_stats[i][0],
			$tcp_src_stats[i][1],
			$tcp_src_stats[i][2],
			$tcp_src_stats[i][3],
			$tcp_dest_stats[i][0],
			$tcp_dest_stats[i][1],
			$tcp_dest_stats[i][2],
			$tcp_dest_stats[i][3],
			$udp_src_stats[i][0],
			$udp_src_stats[i][1],
			$udp_src_stats[i][2],
			$udp_src_stats[i][3],
			$udp_dest_stats[i][0],
			$udp_dest_stats[i][1],
			$udp_dest_stats[i][2],
			$udp_dest_stats[i][3]);
end
